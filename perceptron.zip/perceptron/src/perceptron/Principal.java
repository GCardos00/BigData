package perceptron;

public class Principal {
    public static void main(String[] args) {
        // Cria��o de um objeto do Perceptron
        Perceptron perceptron = new Perceptron();

        // Inicia o treinamento do Perceptron
        System.out.println("Iniciando o treinamento...");
        perceptron.treinar();

        // Exibe o n�mero de �pocas necess�rias para treinar
        System.out.println("Treinamento conclu�do ap�s " + perceptron.getCount() + " �pocas.");

        // Teste do Perceptron com as combina��es de entrada
        System.out.println("\nTestando a rede com as entradas:");
        System.out.println("Entrada 1 | Entrada 2 | Sa�da Esperada | Sa�da Obtida");
        
        for (int i = 0; i < 4; i++) {
            int entrada1 = perceptron.getMatrizAprendizado()[i][0];
            int entrada2 = perceptron.getMatrizAprendizado()[i][1];
            int saidaEsperada = perceptron.getMatrizAprendizado()[i][2];
            int saidaObtida = perceptron.executar(entrada1, entrada2);
            
            System.out.printf("%d\t\t%d\t\t%d\t\t%d\n", entrada1, entrada2, saidaEsperada, saidaObtida);
        }
    }
}
